% Draw 6 "Xeno disks" with color that fade into the background.
% A sequence of disks where the (k+1)th disk has half the diameter 
%   of the kth disk.

close all
figure
axis ([0 2 -1 1])
axis equal
hold on

% Draw black background
DrawRect(0,-1,2,2,'k')
disp('k    color')

x= 0;  % Left tangent point of first disk
d= 1;  % Diameter of first disk
n= 6;  % Number of disks to be drawn
yellow= [1 1 0];
black= [0 0 0];

% Draw sequence of disks
for k= 1:n
   % colr is the color vector of the kth disk
   %   f is fraction of black; 1-f is fraction of yellow
   f= (k-1)/(n-1);
   colr= f*black + (1-f)*yellow;
   DrawDisk(x+d/2, 0, d/2, colr)
   fprintf('%d  %.3f %.3f %.3f\n', k, colr(1), colr(2), colr(3))
   pause(.5)
   x= x+d; 
   d= d/2;
end


