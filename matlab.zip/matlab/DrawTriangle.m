function DrawTriangle (P, Q, R, c)
% Draw c-colored triangle; triangle vertices are points P, Q, and R.

fill([P.x Q.x R.x],[P.y Q.y R.y],c)
