function [x, y] = CirclePoints(n)
% n is a positive integer.
% x and y are length-n vectors that represent the coordinates of 
%   n points around a circle.

x= zeros(1,n);
y= zeros(1,n);

theta = 2*pi/n;
for k=1:n
    x(k) = cos(theta*k);
    y(k) = sin(theta*k);
end