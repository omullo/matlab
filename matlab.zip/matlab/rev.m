
function z=foo(x,y)
z=y+1;
x=x+6;
y=2;
fprintf('x is %d\n',x)
fprintf('z is %d\n',z)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
