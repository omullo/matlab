% Script moreNestedStars
% Draw a sequence of *a sequence of nested stars*!

close all
figure
axis equal off
hold on

% Center of each figure in the sequence is (0,0),(2,2),...,(8,8)
for x = 0:2:8

    y = x;

    % Draw background: s-by-s black square centered at (x,y)
    s = 2.1;
    DrawRect(x-s/2,y-s/2,s,s,'k')

    % Sequence of stars...
    % The radius of the kth star is stored in r...
    r = 1;  k = 1;  rSmallest = .1;
    while r >= rSmallest
        if rem(k,2)==1
            % Odd-indexed stars are magenta...
            DrawStar(x,y,r,'m')
        else
            % Even indexed stars are yellow...
            DrawStar(x,y,r,'y')
        end
        % For the next star, reduce the radius by a factor of 1.2 and increment
        % the star-counting index...
        r = r/1.2;
        k = k+1;
    end

end

hold off
shg