% Script PickUpStix
% Draw sticks (lines) with random endpoints and in random colors

close all
figure
s = 'rgbmcy';  % 6 color "names" encoded in a string
set(gcf,'color','k')
axis equal off
hold on
for k=1:100
    % Generate two randomly located points...
    P = MakePoint(randn(1),randn(1));
    Q = MakePoint(randn(1),randn(1));
    % Pick one of the six colors randomly,
    c = s(ceil(6*rand(1)));
    DrawLine(P,Q,c)
end