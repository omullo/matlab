% Script nestedStars
% Draws a sequence of nested stars. The first one has radius 1 and
% is magenta.
% Thereafter, the stars alternate in color: yellow, magenta,
% yellow, magenta, etc. Each star has radius that is smaller by
% a factor 1.2 than the radius of the previous star. The process
% continues until the radius is <= .1.

close all
figure
axis equal off
hold on

% Draw background: s-by-s black square centered at (x,y)
x = 0; y = 0;  % square centered at origin
s = 2.1;
DrawRect(x-s/2,y-s/2,s,s,'k')

% Sequence of stars...
% The radius of the kth star is stored in r...
r = 1;  k = 1;  rSmallest = .1;
while r >= rSmallest
    if rem(k,2)==1
        %       Odd-indexed stars are magenta...
        DrawStar(x,y,r,'m')
    else
        %       Even indexed stars are yellow...
        DrawStar(x,y,r,'y')
    end
    %    For the next star, reduce the radius by a factor of 1.2 and increment
    %    the star-counting index...
    r = r/1.2;
    k = k+1;
    pause(.3)
end

hold off
shg % Show Graphics--bring most recent graphics window to the front