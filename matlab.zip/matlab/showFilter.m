% Show the noise filtering operation
% *** Takes several minutes to run! ***

close all
C = imread('LawSchool.jpg');

% Show the Original...
figure
imshow(C)
title('Noise Added','Fontsize',14)
pause

% Filter noise
MedFilterC1 = MedianFilter(C,1);
figure
imshow(MedFilterC1)
title('The Original with Noise After MedianFilter','Fontsize',14)


