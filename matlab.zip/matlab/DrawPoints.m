function DrawPoints(P)
% Adds the points to the current figure.
% P is a length n structure array encoding points.

for k=1:length(P)
    plot(P(k).x,P(k).y,'oy')
end