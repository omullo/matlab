% Draw 3 disks fading from yellow to black.

close all
figure
axis ([0 6 -1 1])
axis equal off
hold on

r= 1;  % radius of  disk
yellow= [1 1 0];
black= [0 0 0];

% Left disk yellow
DrawDisk(1,0,r,yellow)

% Right disk black 
DrawDisk(5,0,r,black)

% Middle disk with average color
colr= 0.5*yellow + 0.5*black;
DrawDisk(3,0,r,colr)

hold off


