% Print the times table for a user-specified range

disp('Show the times table for a specified range')
lo= input('What is the lower bound? ');
hi= input('What is the upper bound? ');

for r= lo:hi
    % At row r: print products r*c where c=lo,..,hi
    for c= lo:hi
        fprintf('%6d ', r*c)
    end
    fprintf('\n')
end
