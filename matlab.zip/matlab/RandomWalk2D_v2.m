function [x, y] = RandomWalk2D_v2(N)
% Simulate a 2D random walk in an (2N+1)-by-(2N+1) grid.
% N is a positive integer.
% Walk starts from the middle and continues until the an edge, abs(N),
% is reached.
% x and y are row vectors with the property that (x(k),y(k)) is the
% location of the token after k hops, k=1:length(x).

% Initializations...
k=0;  xc=0;  yc=0;

% Vectors to represent change in four directions
%         N  E  S  W
deltaX= [ 0  1  0 -1];
deltaY= [ 1  0 -1  0];
 
% In general, (xc,yc) is the location after k hops.
while abs(xc)<N && abs(yc)< N
    % Standing at (xc,yc), randomly select a step
    r= ceil(rand*4);  % r is random in [1..4]
    xc= xc + deltaX(r);
    yc= yc + deltaY(r);

    % Record location...
    k= k + 1;  x(k)= xc;  y(k)= yc;
end