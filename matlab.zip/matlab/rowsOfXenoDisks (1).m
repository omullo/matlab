% Draw rows of "Xeno disks" with color that fade into the background.
% A sequence of disks where the (k+1)th disk has half the diameter 
%   of the kth disk.

close all
figure
axis ([0 2 -1 4])
axis equal off
hold on

% Draw black background
DrawRect(0,-1,2,5,'k')
disp(' y     color')

n= 6;  % Number of disks to be drawn on a row
yellow= [1 1 0];
black= [0 0 0];

% Set y-coordinates at which rows of Xeno disks are drawn
for y= 0:3

    x= 0;  % Left tangent point of first disk
    d= 1;  % Diameter of first disk

    % Draw one row of disks
    for k= 1:n
       % colr is the color vector of the kth disk
       %   f is fraction of black; 1-f is fraction of yellow
       f= (k-1)/(n-1);
       colr= f*black + (1-f)*yellow;   
       DrawDisk(x+d/2, y, d/2, colr)
       fprintf('y=%.1f  %.3f %.3f %.3f\n', y, colr(1), colr(2), colr(3))
       x= x+d; 
       d= d/2;
    end

    pause
    shg

end

hold off