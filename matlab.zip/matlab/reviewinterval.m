function Inter = overlap(self, other)
% If self and the other Interval overlap, then Inter is the handle of the
% overlapped Interval; otherwise Inter is an empty array of type Interval.
left= max(self.left, other.left);
right= min(self.right, other.right);
if left >= right
    Inter= Interval.empty();
else
    Inter=Interval(left,right);
    
end
end