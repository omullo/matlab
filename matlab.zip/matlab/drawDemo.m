% Demonstrate the use of the functions
%   drawRect, drawDisk, and drawStar

close all       % Close all figure windows
figure          % Start a new figure window
axis equal off  % Set x and y scale to be the same; hide axes
hold on         % "Add-in mode" is on
 
DrawRect(0,0,2,2,'k')
DrawDisk(1,1,1,'m')
DrawStar(1,1,1,'y')
 
hold off  % "Add-in mode" is off
