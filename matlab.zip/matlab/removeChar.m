function s = removeChar(c, s)
% Return string s with all occurrences of character c removed.
% Example of RECURSION
count=0;
if length(s)==0  % Base case: nothing left to do
    return
else
    if s(1)~=c
        % return string is s(1) and remaining s with char c removed
        s= [s(1) removeChar(c, s(2:length(s)))];
    else
        % return string is just remaining s with char c removed
        s= removeChar(c, s(2:length(s)));
        count=count+1
    end
end