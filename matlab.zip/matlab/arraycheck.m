% function w=interpld(v)
% nv=length(v);
% %nw=2*nv -1;
% for k=1:nv-1
%     w(2*k-1)=v(k);
%     w(2*k)=v(k)/2 +v(k+1)/2;
% %     w(2*k)=inter
% end
% w(2*nv-1)=v(nv)
% end
%  
function w=arraycheck(v)
nv= length(v);
for k= 1:nv-1 % k is an index of v
% copy a value
w(2*k-1)= v(k);
% add an interpolated value
w(2*k)= v(k)/2 + v(k+1)/2;
end
% copy last value
w(2*nv-1)= v(nv);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%