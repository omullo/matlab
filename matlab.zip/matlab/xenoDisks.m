% Draw 20 "Xeno disks":  A sequence of disks where the (k+1)th disk has
% half the diameter of the kth disk.

close all
figure
axis ([0 2 -1 1])
axis equal 
hold on

% Draw black background
DrawRect(0,-1,2,2,'k')
disp(' k   diameter')

x= 0;  % Left tangent point of first disk
d= 1;  % Diameter of first disk
n= 20; % Number of disks to be drawn
% Draw sequence of disks
for k= 1:n
   fprintf('%2d  %10.8f \n', k, d)
   DrawDisk(x+d/2, 0, d/2, 'y')
   x= x+d; 
   d= d/2;
end


hold off