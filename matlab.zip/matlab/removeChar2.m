function s = removeChar2(c, s)
% Return string s with all occurrences of character c removed.
% Example of RECURSION

% This version is removeChar*2*, which does the same thing as removeChar, 
% but here the base case (when is empty, i.e., has length zero) is implied.
% The version in removeChar explicity states and handles base case.

if length(s) > 0
    if s(1)~=c
        % return string is s(1) and remaining s with char c removed
        s= [s(1) removeChar2(c, s(2:length(s)))];
    else
        % return string is just remaining s with char c removed
        s= removeChar2(c, s(2:length(s)));
    end
end