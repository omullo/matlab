% Plot a function two different ways:
%   - one point at a time
%   - using vectors of x and y values

close all

figure  % figure 1
hold on
% Plot one point at a time
for x=  -2:.01:3
    y= sin(5*x)*exp(-x/2)/(1+x^2);  % NON-vectorized operations
    plot(x,y,'.')
end
hold off

figure  % figure 2
% Plot using vectors of x and y values. 
% Vector b is computed via VECTORIZED arithmetic operations.
a= linspace(-2,3,501);
b= sin(5*a).*exp(-a/2)./(1+a.^2);
plot(a,b,'.')


    