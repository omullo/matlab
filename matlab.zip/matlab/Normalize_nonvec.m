function [xNew,yNew] = Normalize_nonvec(x,y)
% x and y are column n-vectors that define the vertices of a polygon P.
% xNew and yNew are the vertices of a polygon obtained by scaling P so that
% the vertex furthest from the origin is on the unit circle

n = length(x);
xNew = zeros(n,1); 
yNew = zeros(n,1);

% Max distance to origin...
for k = 1:n
    d(k) = sqrt(x(k)^2 + y(k)^2);
end
maxD = max(d);

% Normalize so furthest vertex is on the unit circle..
for k = 1:n
    xNew(k) = x(k)/maxD;  
    yNew(k) = y(k)/maxD;
end
