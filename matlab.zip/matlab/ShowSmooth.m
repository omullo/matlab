% Polygon Smoothing

close all
clc
n = input('Enter the number of polygon edges: ');
nSmoothings = input('Enter the number of smoothings: ');

% Generate a random normalized polygon and translate so the
% centroid of its vertices is at (0,0)...
x = rand(n,1); y = rand(n,1);
[x,y] = Centralize_nonvec(x,y);
[x,y] = Normalize_nonvec(x,y);


% Display the original polygon...
figure
set(gcf,'position',[10 100 1000 500])
subplot(1,2,1)
plot([x;x(1)],[y;y(1)],'k',x,y,'or')
axis([-1.2 1.2 -1.2 1.2])
axis equal off
title('Original Polygon (Normalized)','FontWeight','bold','FontSize',14)

% Repeatedly smooth, centralize, and normalize the polygon...
for k=1:nSmoothings
    subplot(1,2,2)
    [x,y] = Smooth(x,y);
    [x,y] = Centralize_nonvec(x,y);
    [x,y] = Normalize_nonvec(x,y);
    plot([x ; x(1)],[y ; y(1)],'k',x,y,'or')
    axis([-1.2 1.2 -1.2 1.2])
    axis equal off
    title(sprintf('After %1d Smoothings',k),'FontWeight','bold','FontSize',14)
    pause(.1)
end




