function [num] = randDouble(lo, hi)
% num = random real number in the interval (lo,hi), exclusive

num= rand*(hi-lo) + lo;