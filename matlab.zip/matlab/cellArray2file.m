% % % % % % % % function cellArray2file(CA, fname)
% % % % % % % % % CA is a cell array of strings.
% % % % % % % % % Create a .txt file with the name
% % % % % % % % % specified by the string fname.
% % % % % % % % % The i-th line in the file is CA{i}
% % % % % % % % 
% % % % % % % % fid= fopen([fname '.txt'], 'w');
% % % % % % % % for i= 1:length(CA)
% % % % % % % %     fprintf(fid, '%s\n', CA{i});
% % % % % % % % end
% % % % % % % % fclose(fid);
% % % % % % % 
% % % % % % % 
% % % % % % % nrows=4;
% % % % % % % ncols=6;
% % % % % % % A=ones(nrows,ncols);
% % % % % % % for c=1:ncols
% % % % % % % for r=1:nrows
% % % % % % % if r==c
% % % % % % % A(r,c)=2;
% % % % % % % elseif abs(r-c)==1
% % % % % % % A(r,c)=-1;
% % % % % % % else
% % % % % % % A(r,c)=0
% % % % % % % end
% % % % % % % end
% % % % % % % end
% % % % % % clear all
% % % % % % clc
% % % % % % lim=75;
% % % % % % A=ceil(rand(10,1).*100);
% % % % % % if any(A>lim)
% % % % % %     disp('There is at least one value above the limit')
% % % % % % else
% % % % % %     disp('All the values are below the limit')
% % % % % % end
% % % % % s=10;
% % % % % h=zeros(s);
% % % % % for c=1:s
% % % % %     for r=1:s
% % % % %         h(r,c)=1/(r+c-1)
% % % % %     end 
% % % % % end
% % % % n=10;
% % % % f=n;
% % % % while n>1
% % % %     n=n-1;
% % % %     f=f*n;
% % % % end
% % % % disp(['n! =',f])%num2str(f)])
% % % v=linspace(15,35,5);
% % % for k=1:length(v)-1
% % %     nebV=v(k)+v(k+1);
% % %     disp([nebV]')
% % % end
% % function [vol,LinLen]=cellArray2file(x,y,z)
% % vol=x*y*z;
% % LinLen=x+y+z;
% % fprintf('The volume is %d, The Linear Length is %d', vol,LinLen)
% % end
% nBig=100;
% nSm=2;
% while nbig>=nSm
%     d=2;
%     while(mod(nBig,d)~=0)
%         d=d+1;
%     end
%     if (d==nBig)
%         fprintf('%d is a prime\n',nBig);
%     else 
%         fprintf('%d\n',nBig);
%     end
%     nBig=nBig+1
% end
A = input('Input ray angle: ');
A = rem(A, 360);
if(A<90) 
    quadrant= 1;
% Given nonnegative A, result will be in the interval [0,360) % first condition
% second condition
elseif (A < 180)
    quadrant= 2;
elseif (A < 270) 
    quadrant= 3;
else
    quadrant= 4;
end
fprintf('Ray angle %f lies in quadrant %d\n', A, quadrant);
