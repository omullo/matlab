function s = removeChar_loop(c, s)
% Return string s with all occurrences of character c removed.
% Example of ITERATION

t= '';
for k= 1:length(s)
    if s(k)~=c
        t= [t s(k)];
    end
end
s= t;