% Demonstrate the plot graphics object in Matlab

close all

% Data for plotting sine curve
x= 0:.1:2*pi;
y= sin(x);

%%%% Make use of the plot object (handle graphics)
figure
h1= plot(x,y);  % h1 is the "handle" to a handle graphics object
pause
% To see the properties of this object, use the get built-in function:
disp(get(h1))
pause
% Change some property values by using the set built-in function:
set(h1, 'Linewidth',2, 'Marker','*', 'YData', y/2)
  % Notice that the graphics object redraws itself using the new values
disp(get(h1))
pause


%%%% Do the same thing by calling the plot function twice 
figure
plot(x,y)  % Draws the original graph with a thin line and no marker
pause
% In order to get a heavier line and asterisks as markers, we call plot
% plot again, i.e., make ANOTHER plot:
plot(x,y/2, 'Linewidth',2, 'Marker','*')
pause


%%%% Animate the sine curve by letting a ball (marker) trace the curve
figure
% Creat two graphics objects, the sine curve and the ball:
hns= plot(x,y,'k-', x(1),y(1),'mo');
  % hns is a vector storing the handles to the two plot objects:  hns(1) is
  % the handle to the first object (the black curve); hns(2) is the handle
  % handle to the second object (the magenta ball)
pause
% Animate the ball simply by changing its Xdata and Ydata values:
for k= 1:length(x)
    set(hns(2), 'Xdata',x(k), 'Ydata',y(k)) 
    pause(.1)
end
% Notice that when the property values (DATA) change, a redrawing (ACTION)
% is done automatically--there was no separate function call to perform the
% draw action on the changed data.  This linkage between the data and 
% action was explicitly defined in the design of handle graphics.

% We can create our own object-oriented designs so that the data "comes 
% with" a set of actions (functions that act on the data).