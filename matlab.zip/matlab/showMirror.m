% Show left-right mirror image -- non-vectorized code

close all

% Convert jpg image to 3D uint8 array and determine its dimensions
A= imread('frank.jpg');
[nr,nc,np]= size(A);

% Display the image
figure
imshow(A)
shg
pause  % wait until user presses a key

% Produce a mirror image
B= zeros(nr,nc,np);
B= uint8(B);  % Type for image color values
for r= 1:nr
  for c= 1:nc
    for p= 1:np
      B(r,c,p)= A(r,nc-c+1,p);
    end
  end
end

% Display mirror, then store 3-d array data as a jpg image
figure
imshow(B)
shg
imwrite(B,'frankmirror.jpg') 
