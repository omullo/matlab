% Areas of regular polygons inscribed and 
% circumscribed in the unit circle

disp('Compute areas of inscribed and circumscribed n-gons')
prompt= 'Enter n (n>2 to calculate areas or n=-9999 to stop): ';
n= input(prompt);  % no. of sides of n-gon
stop= -9999;       % stopping signal
while (n ~= stop)
   %Compute and display areas of n-gons
   innerA= (n/2)*sin(2*pi/n);
   outerA= n*tan(pi/n);
   fprintf('\n n\tInner Area\tOuterArea\n')
   fprintf('%d\t%.6f\t%.6f\n', n, innerA, outerA)
   n= input('Enter integer n: ');
end
