% Draw a frame on the edge of a grayscale jpeg image --
%   a more verbose but more efficient version

close all

% Read the original picture (jpeg) and show it:
P= imread('frank.jpg');
imshow(P);
pause

% Add a frame 50 pixels wide on the edge of picture
width= 50;
frameColor= 200;  % white
[nr,nc]= size(P);
% Top and bottom bars:
for r= 1:width
    for c= 1:nc
        P(r,c)     = frameColor;
        P(nr-r+1,c)= frameColor;
    end
end
% Left and right bars:
for c= 1:width
    for r= width+1:nr-width+1
        P(r,c)     = frameColor;
        P(r,nc-c+1)= frameColor;
    end
end

imshow(P)