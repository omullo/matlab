function CA = file2cellArray(fname)
% fname is a string that names a .txt file in the current directory.
% CA is a cell array with CA{k} being the k-th line in the file.

fid= fopen([fname '.txt'], 'r');
k= 0;
while ~feof(fid)
   k= k+1;
   CA{k}= fgetl(fid);
end
fclose(fid);