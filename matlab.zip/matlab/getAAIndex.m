function ind = getAAIndex(aa)
% Returns the index of amino acid.
% aa is a length 3 row vector of chars; if it is an amino acid mnemonic,
% then ind is the index of aa in the Amino Acid table.  Otherwise throw an
% error.

% A is the Amino Acid table: a 20-by-3 char array where A(i,:) names 
% the ith amino acid.
A= [ 'Ala' ; 'Arg' ; 'Asn' ; 'Asp' ; 'Cys';... 
     'Glu' ; 'Gln' ; 'Gly' ; 'His' ; 'Ile';...
     'Leu' ; 'Lys' ; 'Met' ; 'Phe' ; 'Pro';...
     'Ser' ; 'Thr' ; 'Trp' ; 'Tyr' ; 'Val'];

nr= size(A, 1);
ind = 1;
while ind<=nr && ~strcmp(aa, A(ind,:))
    ind=ind+1;
end
if ind>nr
    error('%s is not an amino acid mnemonic', aa)
end
