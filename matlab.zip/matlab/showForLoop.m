% showForLoop
% Show screen output for the stick experiment in order to illustrate the
% for loop

% A stick of unit length is randomly split in two pieces.  Estimate the
% average length of the short piece.

clc
n= 10;     % number of trials
total= 0;  % accumulated length of short pieces so far

for k= 1:n
    fprintf('Top of loop.  k is %d. ', k)
    breakPt= rand;
    fprintf(' Split at %.2f. ', breakPt)
    shortPiece= min(breakPt, 1-breakPt);
    total= total + shortPiece;
    fprintf(' Bottom of loop.\n')
    pause
end

aveLength= total/n;
fprintf('Estimated average length is %.4f (%d trials)\n',...
        aveLength, n)