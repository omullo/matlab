% LotsaTriangles
% Draws all possible triangles formed by connecting
% three randomly sitiated points on the unit circle.

close all
figure
n = 6;

axis([-1.2 1.2 -1.2 1.2])
set(gcf, 'color', 'k')
axis equal off
hold on

% Draw the circle points...
P = CirclePoints(n);
for k=1:n
    text(1.15*P(k).x,1.15*P(k).y,num2str(k),'color','y')
end

% For each (i,j,k) triple satisfying i < j < k...
for i=1:n-2
    for j=i+1:n-1
        for k=j+1:n
            % Draw a triangle
            DrawTriangle(P(i),P(j),P(k),'m')
            DrawPoints(P)
            title(sprintf('( i , j , k ) =  ( %2d , %2d , %2d )',i,j,k),...
                'color', 'w', 'Fontsize', 14)
            pause
            DrawTriangle(P(i),P(j),P(k),'k')
        end
    end
end