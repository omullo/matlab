function val = minInMatrix(M)
% val is the smallest value in matrix M

val= M(1,1);
[nr, nc]= size(M);

for r= 1:nr
    % Scan row r
    for c= 1:nc
        if  M(r,c)<val 
            val= M(r,c);
        end
    end
end
