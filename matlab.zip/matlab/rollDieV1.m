function count = rollDieV1(rolls)
% Simulate rolling of a fair 6-sided die
% Usage:  count = rollDieV1(rolls)
%   ROLLS is the number of times to roll the die
%   COUNT is vector of how many times each outcome occurs
%     count(f) is the number of times face f occurs

FACES= 6;               % number of faces on die
count= zeros(1,FACES);  % bins to store counts

% Count outcomes of rolling a FAIR die
for k= 1:rolls
    % roll the die
    face= ceil(rand*FACES);
    % increment appropriate bin
    if face==1
        count(1)= count(1) + 1;
    elseif face==2
        count(2)= count(2) + 1;
    elseif face==3
        count(3)= count(3) + 1;
    elseif face==4
        count(4)= count(4) + 1;
    elseif face==5
        count(5)= count(5) + 1;
    else 
        count(6)= count(6) + 1;
    end
end
% The if-statement above is unnecessary!
% See function rollDie.


% Show histogram of outcome
close all
bar(1:FACES, count);
title(sprintf('Outcomes from %d rolls of fair die', rolls));
xlabel('Outcome');  ylabel('Count');
shg
