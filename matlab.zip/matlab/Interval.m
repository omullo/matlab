classdef Interval < handle
% An Interval has a left endpoint and a right endpoint.
    
    properties
       left
       right
    end
    
    methods
        function Inter = Interval(lt, rt)
        % Constructor:  construct an Interval objectedit
            Inter.left= lt;
            Inter.right= rt;
        end
        
        function scale(self, f)
        % Scale the interval by a factor f
            w= self.right - self.left;
            self.right= self.left + w*f;
        end
        
    end
    
end %classdef