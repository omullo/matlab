A=imread('frank.jpg');
[nr,nc,np]=size(A);
B=zeros(nr,nc,np);
B=uint8(B);
for r=1:nr
    for c=1:nc
        for p=1:np
            B(r,c,p)=A(r,nc-c+1,p);
        end
    end
end
imshow(B)
imwrite(B,'franknew.jpg')