% % Play with the Interval class
% 
% p = Interval(3,7);  % p references a newly created Interval object
% disp(p)             % show the property values of this Interval
% 
% % Access the object's properties:
% fprintf('Left end of Interval is %.1f\n', p.left)
% fprintf('Right end of Interval is %.1f\n', p.right)
% fprintf('Width of Interval is %.1f\n\n', p.right-p.left)
% 
% % Call object's method:
% p.scale(2)  % double the width of the interval
% disp('After doubling the width...')
% fprintf('Width of Interval is %.1f\n', p.right-p.left)
% fprintf('Left end of Interval is %.1f\n', p.left)
% fprintf('Right end of Interval is %.1f\n', p.right)
function scale2(v,f)
v=v*f;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

v=[2 4 1];
scale2(v,5)
disp(v)