function drawColorDot(x, y, color)
% Draw a dot on at position(x,y). In red if color=0, otherwise blue.

if (color==0)
    plot(x,y,'r.','markersize',20)
else
    plot(x,y,'b.','markersize',20)
end