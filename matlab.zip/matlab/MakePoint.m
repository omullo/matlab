function P = MakePoint(x,y)
% P is a point structure.
% P.x and P.y are assigned the values x and y.

P = struct('x',x,'y',y);
