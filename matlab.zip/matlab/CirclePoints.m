function P = CirclePoints(n)
% P is a structure array holding n points around a circle.
% In particular, (P(k).x,P(k).y) is the point (cos(k*theta),sin(k*theta))
% where theta = 2pi/n.

theta = 2*pi/n;
for k=1:n
    c = cos(theta*k);
    s = sin(theta*k);
    P(k) = MakePoint(c,s);
end