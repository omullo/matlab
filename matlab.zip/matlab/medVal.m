function med = medVal(C)
% med is the median of the values in matrix C

% Convert matrix C to a row vector v
v= [];
for r= 1:size(C,1)
   v= [v C(r,:)];
end

% Median
med= median(v);
