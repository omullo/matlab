function [x, y] = RandomWalk2D(N)
% Simulate a 2D random walk in a 2N-1 by 2N-1 grid.
% N is a positive integer.
% Walk starts from (0,0) and continues until the an edge, abs(N),
% is reached.
% x and y are row vectors with the property that (x(k),y(k)) is the
% location of the token after k hops, k=1:length(x).

% Initializations...
k=0;  xc=0;  yc=0;

% In general, (xc,yc) is the location after k hops.
while abs(xc)<N && abs(yc)< N
    % Standing at (xc,yc), randomly select a step
    r= rand;
    if r < .25
        yc= yc + 1;  % north
    elseif r < .5
        xc= xc + 1;  % east
    elseif r < .75
        yc= yc -1;   % south
    else
        xc= xc -1;   % west
    end
    % Record location...
    k= k + 1;  x(k)= xc;  y(k)= yc;
end