function [xNew,yNew] = Centralize_nonvec(x,y)
% x and y are column n-vectors that define the vertices of a polygon P.
% xNew and yNew are the vertices of a polygon obtained by translating
% P so that its centroid is at (0,0).

n = length(x);
xNew = zeros(n,1); 
yNew = zeros(n,1);

% Compute the centroid...
xBar = sum(x)/n; 
yBar = sum(y)/n;

% Translate the polygon...
for k= 1:n
    xNew(k) = x(k)-xBar; 
    yNew(k) = y(k)-yBar;
end

