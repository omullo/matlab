% Floating point error
% Is the while-loop below an infinite loop?

k = 0;
while 1 + 1/2^k > 1
    k = k+1;
end
disp(k)