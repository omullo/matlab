function B = MedianFilter(A,r)
% A is an m-by-n uint8 array.
% B is an m-by-n uint8 array obtained from A by median filtering
% with radius r neighborhoods

  [m,n] = size(A);
  B = uint8(zeros(m,n));
  for i=1:m
     for j=1:n
        iMin = max(1,i-r);
        iMax = min(m,i+r);
        jMin = max(1,j-r);
        jMax = min(n,j+r);
        C = A(iMin:iMax,jMin:jMax);
        B(i,j) = medVal(C);
     end
  end