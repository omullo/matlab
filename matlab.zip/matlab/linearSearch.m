function f = linearSearch(x, v)
% Linear Search.  f is index of first occurrence of scalar x in vector v.
% f is -1 if x is not found.

k= 1;
while  k<=length(v) && v(k)~=x 
    k= k + 1;
end
if  k>length(v)  
    f= -1; % signal for x not found
else
    f= k;
end