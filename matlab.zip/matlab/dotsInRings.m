function dotsInRings(d, c)
% Draw d random dots in each of c concentric rings

% Set up figure window
close all;  figure;  
axis equal
axis([-c c -c c])
hold on

% Put dots in the area between circles with radii rRing and (rRing-1)
for rRing= 1:c
    % Draw d dots
    for count= 1:d
        theta= randDouble(0, 360);
        radius= randDouble(rRing-1, rRing);
        [x, y]= polar2xy(radius, theta);
        drawColorDot(x, y, rem(rRing,2));
        pause(0.01);
    end
end

hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function drawColorDot(x, y, color)
% Draw a dot on at position(x,y). In red if color=0, otherwise blue.

if (color==0)
    plot(x,y,'r.','markersize',20)
else
    plot(x,y,'b.','markersize',20)
end

