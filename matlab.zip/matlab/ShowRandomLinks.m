% ShowRandomLinks
% Traverse UPPER TRIANGULAR PART MATRIX--at each iteration consider both
% A(i,j) AND A(j,i).

n = 10;  % No. of web pages
A = RandomLinks(n);
close all
figure
axis equal square off
hold on

% n webpages laid out around a circle
[x, y] = CirclePoints(n);
plot(x, y, 'ko')
% Show the page index on the diagram:
for k= 1:length(x)
   text(x(k),y(k), sprintf('  %d', k)) 
end

% Use link matrix A to connect appropriate pages (points)
bi= [];  di= [];
for i= 1:n
    for j= i+1:n
        % Nested loops traverse UPPER TRIANGULAR matrix only, 
        % so each link is drawn once only.
        if A(i,j)==1 && A(j,i)==1  % bidirectional link
            plot([x(j) x(i)], [y(j) y(i)], 'b')
            bi= [bi; [i j]];
        elseif A(i,j)==1  % link to page i from page j
            xmid = (x(i) + x(j)) / 2;
            ymid = (y(i) + y(j)) / 2;
            plot ([x(j), xmid], [y(j), ymid], 'k')
            plot ([xmid, x(i)], [ymid, y(i)], 'r')
            di= [di; [i j]];
        elseif A(j,i)==1  % link to page j from page i
            xmid = (x(i) + x(j)) / 2;
            ymid = (y(i) + y(j)) / 2;
            plot ([x(i), xmid], [y(i), ymid], 'k')
            plot ([xmid, x(j)], [ymid, y(j)], 'r')
            di= [di; [i j]];
        end
    end
end
shg

