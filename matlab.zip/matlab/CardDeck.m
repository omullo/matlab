function D = CardDeck()
% D is a 1-by-52 cell array of strings that define a card deck

suit = {'Hearts', 'Clubs', 'Spades', 'Diamonds'};
rank = {'A', '2', '3', '4', '5', '6', '7', '8', '9', '10','J','Q','K'};

D = cell(1,52);

i = 1;  % index of the next card to be set up

for k= 1:4
    % Set up the cards in suit k
    for j= 1:13
        D{i} = [ rank{j} ' ' suit{k} ];
        i = i+1;
    end
end

