% Tabulate the amino acid frequency counts of a gene sequence that codes
% for a protein

% Gene sequence of a protein
p= ['TTCGGGAGCCTGGGCGTTACGTTAATGAAAGATGAAATATGTACCAACGACAATGACATTGAA' ...
    'AACTATGTAATTCGATGCCATAAGTGCAAGCCGGACCGGGAAGAGCACCTCCGCCAAAGTGCC' ...
    'TACTCTCTTAAATGTATCGTCTTACTATGTCTTTTTCCCCATGGAGTGGCAACGTATAGTCGA' ...
    'TGCGGTCCCAGACCGCGATTCCTCTCGCCGTATTGGGGTCCAGATGCCTCCCTCCTTTATATG' ...
    'ATGACAAGCAAAAACTGTTGGGCCCTTAATGTACCGCTCATAGCGCCCGCACGTCTACGCAGC'];

% Build histogram data
nAA= 20;  % Number of amino acids
count= zeros(nAA, 1);
for k= 1:3:length(p)-2  
    codon= p(k:k+2);
    mnem= getMnemonic(codon);
    ind= getAAIndex(mnem);
    count(ind)= count(ind) + 1;
end

% Draw bar graph
bar(1:nAA, count)
title('Tally of Amino Acids in a Protein', 'FontSize',14)
axis tight
set(gca,'xTick',1:20)
set(gca,'xTickLabel',...
    {'Ala','Arg','Asn','Asp','Cys','Glu','Gln','Gly','His','Ile',...
     'Leu','Lys','Met','Phe','Pro','Ser','Thr','Trp','Tyr','Val'}, ...
     'FontSize',14,'FontWeight','Bold')
set(gcf,'position',[30 50 950 600])
shg

