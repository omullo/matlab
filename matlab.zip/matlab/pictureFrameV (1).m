% Draw a frame on the edge of a grayscale jpeg image
%   using vectorized code

close all

% Read the original picture (jpeg) and show it:
P= imread('bwduck.jpg');
imshow(P);
pause

% Add a frame 50 pixels wide on the edge of picture
width= 50;
frameColor= 255;  % white
[nr,nc]= size(P);

P(1:width, 1:nc)      = frameColor*ones(width,nc);                  %top
P(nr-width+1:nr, 1:nc)= frameColor*ones(width,nc);                  %bottom
P(width+1:nr-width, 1:width)= frameColor*ones(nr-2*width,width);    %left
P(width+1:nr-width, nc-width+1:nc)= frameColor*ones(nr-2*width,width); %right

imshow(P)