% Script File: SHowCheapest

% Cost matrix for factory i to produce product j
C = [ 10 36 22 15 62; ...
      12 35 20 12 66;...
      13 37 21 16 59];

% Inventory matrix:  no. of product j at factory i
Inv = [ 38  5 99 34 42;...
        82 19 83 12 42;...
        51 29 21 56 87];
    
% Purchase order:  no. of different products wanted
PO = [ 1  0  12  29  5];

[iBest, minBill] = Cheapest(C,Inv,PO)
  