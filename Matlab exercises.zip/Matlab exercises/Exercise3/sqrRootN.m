% Compute square root of A by making N increasingly square rectangles all

A= input('Enter a positive value: ');
N= input('Enter a positive integer: ');
fprintf('Estimate sqrt(%f) by making increasingly square rectangles\n',A)
     
% First rectangle
L= A;
W= 1;
% Rectangles 2 through N
for k= 2:N
   fprintf('%d  Length %15.12f, Width %15.12f\n', k-1,L,W)
   L= (L+W)/2;
   W= A/L;
end
fprintf('%d  Length %15.12f, Width %15.12f\n', k,L,W)
fprintf('With %d rectangles, sqrt(%f) is approximately %.2f.\n',...
        N,A,(L+W)/2)

