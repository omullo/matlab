% Pi via summation

clc
disp('   n     T_error      RT_error ')
disp('----------------------------------')

% Initialize the running sums...
R= 0;  T= 0;

% The longest summation.. 
nMax= 1000;

for n= 1:nMax
    % Compute the n-th terms...
    T_term = 1/n^2;
    if mod(n,2)==1
        R_term = 1/(2*n-1);
    else
        R_term = -1/(2*n-1);
    end
    % Update the running sums..
    T= T + T_term;
    R= R + R_term;
    % Display the errorss if n is a multiple of 100...
    if (rem(n,100)==0)
        T_err= abs( sqrt(6*T) - pi);
        R_err= abs( 4*R - pi);
        fprintf('%5d  %10.1e   %10.1e ', n, T_err, R_err)
    end
end

% How could the R_term value be determined without an if-statement?
% Hint. How does the value of x change in this sequence:
%      x = 1; x = -x; x = -x; x = -x; x = -x