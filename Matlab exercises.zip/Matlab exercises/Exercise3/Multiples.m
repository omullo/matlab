% Print all the multiples of an integer k between k and 1000

k = input('Please enter a positive integer smaller than 1000: ');
for j = k:k:1000
   fprintf('%d ', j)
end
fprintf('\n')