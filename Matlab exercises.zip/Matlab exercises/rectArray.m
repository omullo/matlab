function Z = rectArray(n,xmax,ymax)
% Z is a 1-d array of n rectangle structs, each as defined by function
% MakeRect and each is randomly generated in the area bounded by (0,0),
% (xmax,0), (xmax,ymax), and (0,ymax). The first generated rectangle is
% Z(1), the second generated rectangle is Z(2), and so forth.
% >>>>>a and b are real numbers that satisfy a <= b.
% c and d are real numbers that satisfy c <= d.
%  R.a <= x <= R.b, R.c <= y <= R

%Initialize Z as an empty cell array

close all

Z=struct('rectangles',{});

% Draw n rectangles randomly 
for k=1:n
    a=ceil(rand*xmax);
    b=ceil(rand*xmax);
    
    if  a>=b
        while a>=b
        a=ceil(rand*xmax);
        b=ceil(rand*xmax);
        end
    end
    
    d=ceil(rand*(ymax));
    c=ceil(rand*(ymax));
    
    if c>=d
        while c>=d
        c=ceil(rand*(ymax));
        d=ceil(rand*(ymax));
        end
    end
   R=MakeRect(a,b,c,d);
    Z(k).rectangles=R;
    
    figure(1);
    axis('equal')
    axis([0 xmax 0 ymax])
    hold on
    title('Random Rectangles')
    ShowRect(R,[1 0 1])
end

hold off