x=4;
y=12;
z=foo(x,x);
fprintf('z is %d\n', z)
fprintf('x is %d\n',x)
fprintf('y is %d\n',y)