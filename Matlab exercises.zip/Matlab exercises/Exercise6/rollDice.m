function rollDice(n,d)
% Simulate rolling of d fair dice n times (trials)
% Roll all d dice in each trial

FACES= 6;                % six-sided dice
maxOut= FACES*d;         % highest possible outcome from rolling all dice
count= zeros(1,maxOut);  % bins to store counts
  % count(c) is the number of occurrences of outcome c 

for i = 1:n
    % Roll the d dice
    outcome= 0;  % total outcome from all n dice
    for k= 1:d
        outcome= outcome + ceil(rand(1)*FACES);
    end
    % Increment the correct bin
    count(outcome)= count(outcome) + 1;
end

% Show histogram of outcome
bar(d:maxOut, count(d:length(count)));
message= sprintf('%d rolls of %d fair dice', n, d);
title(message);
xlabel('Outcome');  ylabel('Count');
