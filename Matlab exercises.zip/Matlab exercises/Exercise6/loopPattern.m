% Basic loop pattern for a vector

% Given a vector v, display its values
for k= 1:length(v)
    disp(v(k))
end

% Given a vector v, display its maximum value
maxSoFar= v(1);
for k= 2:length(v)
    if v(k)>maxSoFar
        maxSoFar= v(k);
    end
end
disp(maxSoFar)
    