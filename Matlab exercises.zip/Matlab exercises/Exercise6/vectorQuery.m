function found = vectorQuery(v,n,r)
% found is 1 if the number r appears in the first n cells of vector v.
% Otherwise found is 0.

n= min(n,length(v));
found= 0;  % r hasn't been found yet
k= 1;      % index position being evaluated 
while(k<=n && ~found)

    found= (v(k)==r);  %r is found at position k

    %%%% Less concise way to assign to variable found: 
    %    if v(k)==r 
    %        found= 1;
    %    end
    %%%%

    k= k+1;
end


% Using a while-loop allows the loop to end as soon as the number r is
% found.  Using a for-loop (without break) is less efficient since the
% function will have to work through n cells of the array even if r is
% found earlier.
% DO NOT USE break in this course.

    