function a = sequence(m)
% Vector a is a non-repeating sequence of random integers in [1..m].
% Random number generation is stopped the first time a value is repeated.

a= [];   % a intialized as empty vector
len= 0;  % number of values in vector a so far

r= ceil(rand(1)*m);

while ( vectorQuery(a,len,r)==0 )  
    % while r isn't in the first len cells of vector a
    len= len + 1;
    a(len)= r;
    r= ceil(rand(1)*m);
end


% The loop header can be written more concisely as
%
%     while  ~vectorQuery(a,len,r)
%
% since the function vectorQuery returns 1 or 0.