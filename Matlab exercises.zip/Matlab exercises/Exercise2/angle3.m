%Determine in which quadrant angle A lies

A= input('input ray angle: ');
A= mod(A,360);%Given nonnegative A, result will be in the interval [0,360)

if (A<270)
    quadrant= 3;
   if (A<180)
       quadrant= 2;
       if (A<90)
           quadrant= 1;
       end
   end
else
    quadrant= 4;
end

fprintf('Ray angle %5.4f lies in quadrant %5.4f\n', A, quadrant);
