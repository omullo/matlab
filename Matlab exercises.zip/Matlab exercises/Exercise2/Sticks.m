% Sticks

clc 
a = rand
b = rand
c = rand

% Can we make a triangle with sticks having these lengths?
% Key observation: If one stick is longer than (or equal to) 
% the sum of the others, then the answer is no. 

disp('Method 1')
if a >= b+c
    disp('No')
elseif b >= a+c
    disp('No')
elseif c >= a+b
    disp('No')
else
    % If none of the above three tests are true, then it is possible.
    disp('Yes')
end

disp('Method 2')
if (a >= b+c) || (b>=a+c) || (c>=a+b)
    disp('No')
else
    disp('Yes')
end

disp('Method 3')
if (a < b+c) && (b< a+c) && (c < a+b)
    disp('Yes')
else
    disp('No')
end