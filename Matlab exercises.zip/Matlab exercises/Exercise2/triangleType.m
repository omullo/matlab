% Script triangleType

% Let a, b, and c be the interior angles of a triangle.
% Assume a, b, and c are positive integers that sum to 180.
% Determine the triangle type

if ( a~=b && a~=c && b~=c )
    disp('Scalene triangle')
else
    if ( a==b && a==c && b==c )
        disp('Equilateral triangle')
    else
        disp('Isoceles triangle')
    end
end