%Determine in which quadrant angle A lies

A= input('input ray angle: ');
A= mod(A,360);%Given nonnegative A, result will be in the interval [0,360)

if (A<90)
    quadrant= 1;
elseif (A<180)
    quadrant= 2;
elseif (A<270)
    quadrant= 3;
else
    quadrant= 4;
end

fprintf('Ray angle %f lies in quadrant %d\n', A, quadrant);
