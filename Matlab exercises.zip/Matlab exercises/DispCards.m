function DispCards(ca, p, q)
% ca is a cell array of strings.
% p and q are integers that satisfy 1 <= p <=q <=length(ca)
% Displays ca{p} through ca{q}.

% The simplest solution, prints down the screen
% for k= p:q
%     disp(ca{k})
% end

% Print up to four cards in every line displayed
x= 4;  % start new line after printing x cards
idx= p:q;
for k= 1:length(idx)
    fprintf('%14s',(ca{idx(k)}))
    if rem(k,x)==0
        fprintf('\n')
    end
end
fprintf('\n')