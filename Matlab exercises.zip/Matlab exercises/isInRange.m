function tf = isInRange(inter, interArray)
% Inter: an Interval
% interArray: 1-d array of Intervals
% tf: a logical vector the same length as interArray such that tf(k) is
%     true if inter "is in" interArray(k); otherwise tf(k) is false.
n=length(interArray); 
tf= false(1,n)
for k=1:n
    tf(k)=isIn(inter,interArray(k))
end
end