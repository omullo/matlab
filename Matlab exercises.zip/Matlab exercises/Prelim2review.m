% for i=1:4
%     for j=5:6
%         for k=7:9
%             disp([i j k])
%         end
%     end
% end
M=[14 16 18 20; ...
    12 11 10 9; ...
     1  2  3 4; ...
     5  6  7 8 ];
P=zeros(4,4);
for r =2:4
    for c=4:-1:2
        P(r,c)=M(c,r);
    end
end
disp(P)
