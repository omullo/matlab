% tic
% A = rand(12000, 4400);
% B = rand(12000, 4400);
% toc
% C = A'.*B';
% toc
t = zeros(1,100);
for n = 1:100
    A = rand(n,n);
    b = rand(n,1);
    tic;
    x = A\b;
    t(n) = toc;
end
plot(t)
