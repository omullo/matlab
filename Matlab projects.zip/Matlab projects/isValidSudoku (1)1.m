function solution=isValidSudoku(filledPuzzle)
%function checks if input filledPuzzle is a valid sudoku solution.
%filledPuzzle must be a 9-by-9 matrix that has integers in the range 
%[1...9]. Each row, each column and each 3-by-3 submatrix must contain
%integers [1...9] with no repeated values in either row, column or grid.
%function returns output value type logical true if the above conditions 
%are met and returns output value type logical false if they are not met.


%Find size of matrix
[nr,nc]=size(filledPuzzle);
%Determine if matrix is a 9-by-9 matrix
if size(filledPuzzle)~= [9 9]
    solution=false
%If matrix is 9-by-9 matrix, determine if elements are in range [1...9]
elseif all(filledPuzzle<1 | filledPuzzle>9)
    solution=false
%If matrix passes above tests, determine if rows and columns do not have 
%any repeated integers
else
      i=1;     %row index
      j=1;     %column index
      w=true;  %current state of row
      v=true;  %current state of column
      while i<=nr && j<=nc && w==true && v==true
             %check if each column does not have repeated values
             column=filledPuzzle(i,:);
             w=isValidPartition(column);
             %check if each row does not have repeated values
             row=filledPuzzle(:,j);
             v=isValidPartition(row);
             %Update values of row and column indices             
             i=i+1;
             j=j+1;
      end
      %If rows and columns do not have repeated values, 
      %check if each 3-by-3 submatrix is valid
      if w==true && v==true 
         k=1;      %Grid index
         %Initialize submatix to be a 3-by-3 zeros matrix
         grid=[];
         r=true;   %current state of grid
              while k<=nr-2 && r==true
              grid=filledPuzzle(k:k+2,k:k+2);
              r=isValidPartition(grid);
              k=k+3;
              end
              %If grid has no repeated values, solution is true
              if k>nr-2
                 solution=true
              %If grid has repeated values, solution is false       
              else
                 solution=false
              end
       %if rows and columns have repeated values, solution is false       
       else
         solution=false
        
       end
end
end
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sub function isValidPartition
 function val=isValidPartition(subarray)
 %val is a type logical value and subarray is either a length 9 or 3-by-3
 %matrix.
 %function determines if integers in subarray matrix contain only the 
 %integers in the range [1...9].
 
 %If function is a length 9 vector
 if length(subarray)==9
     %check if subarray elements are not the same
     if subarray(1)==subarray(2)
         val=false
     %if the numbers are different, check that the sum is 45 because the 
     %sum of numbers [1...9] is 45
     elseif sum(subarray)~=45
        val=false
     else
         val=true
     end
 %if the subarray is 3-by-3 matrix
 elseif size(subarray)==[3 3]
     %check that the numbers are not the same
     if subarray(1,1)==subarray(1,2)
         val=false
     elseif sum(sum(subarray))~=45
         val=false
     else
        val=true
     end
 else
     val=false
 end
 end


                    
                
                
        