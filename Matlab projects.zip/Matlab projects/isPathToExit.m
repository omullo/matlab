function success = isPathToExit(previous_row, previous_col, current_row, current_col)
% Finds a path from entrance to exit through the maze
% base case
global MAZE ROWLIMIT COLLIMIT ROWEND COLEND
if current_row == ROWEND && current_col == COLEND
    disp(sprintf('(%i, %i)', current_row, current_col));
    success = true;
    return;
else
    success = false;
end
% recursion
if current_row+1 ~= previous_row && MAZE(current_row+1, current_col) ~= '#' && current_row+1 ~= ROWLIMIT && current_row ~= 0 
    success = isPathToExit(current_row, current_col, current_row+1, current_col);
    if success
        disp(sprintf('(%i, %i)', current_row+1, current_col));
        return;
    end
end
if current_row-1 ~= previous_row && MAZE(current_row-1, current_col) ~= '#' && current_row-1 ~= ROWLIMIT && current_row ~= 0
    success = isPathToExit(current_row, current_col, current_row-1, current_col);
    if success
        disp(sprintf('(%i, %i)', current_row-1, current_col));
        return;
    end
    
end
if current_col+1 ~= previous_col && MAZE(current_row, current_col+1) ~= '#' && current_col+1 ~= COLLIMIT && current_col ~= 0
    success = isPathToExit(current_row, current_col, current_row, current_col+1);
    if success
        disp(sprintf('(%i, %i)', current_row, current_col+1));
        return;
    end
end
if current_col-1 ~= previous_col && MAZE(current_row, current_col-1) ~= '#' && current_col-1 ~= COLLIMIT && current_col ~= 0
    success = isPathToExit(current_row, current_col, current_row, current_col+1);
    if success
        fprintf('(%i, %i)\n', current_row, current_col-1);
        return;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function success = Recursive_Fcn(prev_row, prev_col, next_row, next_col)
   if (at maze exit)
       sucess = true
       return
   else
    sucess = false;
   end
    if(prev pt was not from up && up point is clear && ~sucess )
       sucess = recursive statement(up direction)
       if(success)
          print pt
         end
    end
    if(prev pt was not from down && down point is clear && ~sucess )
       sucess = recursive statement(down direction)
       if(success)
          print pt
       end
    end
    if(prev pt was not from lwft && left point is clear && ~sucess )
       sucess = recursive statement(left direction)
       if(success)
          print pt
       end
    end
    if(prev pt not from right && right pt is clear && ~success)
       success = recursive statement(right direction)
       if(success)
          print pt
       end
    end
     return
  %%%%%%   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%