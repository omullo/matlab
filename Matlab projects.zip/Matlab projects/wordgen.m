n=length(W);
index=ceil(rand(1,2)*n);
while(1)==index(2)
    index(2)=ceil(rand*n);
end
disp(W{index(1)})
disp(W{index(2)})