function [colrZ, colrSorted] = rectangles(Z,xmax,ymax,colorS,colorL)
% Draw the rectangles in struct array Z:
% Figure 1 draws the rectangles in the order Z(1), Z(2), ..., Z(n), where n
% is the length of Z. Draw all rectangles in one color of your choice.
% Figure 2 draws the rectangles starting from the largest (by area) to the
% smallest. The colors of the rectangles are linearly interpolated with
% the largest area corresponding to colorL and the smallest area
% corresponding to colorS.
% xmax and ymax are the upper limits of the x- and y-axes in the figures.
% The lower limit of the x- and y-axes is 0.
% colrZ is the n-by-3 matrix where colrZ(k,:) are the rgb values of Z(k).
% colrSorted is the n-by-3 matrix where colrSorted(i,:) are the rgb values
% of the ith smallest rectangle.

%Draw random rectangles
close all
n=length(Z);
figure
x=xmax/4; y=ymax+1;
text(x,y, 'random rectangles','Color',[0 0 0], 'Fontsize',20)
axis equal
axis([0 xmax 0 ymax])
hold on
for k=1:n
    R=Z{k};
    ShowRect(R,'y')
end
hold off
%Ordered rectangles
v=[];
for k=1:n
    v(k)=(Z{k}.right-Z{k}.left)*(Z{k}.top-Z{k}.bot);
end
[Areas,idx]=sort(v);
figure
axis equal
axis([0 xmax 0 ymax])
hold on

for k=n:-1:1
    R=Z{idx(k)};
    slope=1/(Areas(n)-Areas(1));
    f=1-(Areas(n)-Areas(k))*slope;
    c=f*colorL+(1-f)*colorS;
    ShowRect(R,c)
end
hold off
    
