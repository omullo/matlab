function newIm = multiZoom(jName)
% Display an image and "zoom in" user-selected rectangular regions.
% jName is the string that names a JPEG image in the current directory.
% newIm is the uint8 array storing the data of the last "zoom detail." If no zoom
% detail has been calculated then newIm is the empty uint8 array, uint8([]).
% After displaying the image named by jName, repeat the following:
% Accept 2 user mouseclicks on original image defining a rectangular area.
% Compute the "zoom detail" & Display it in a separate figure window.
% If the user mouse clicks indicate a very narrow area (4 pixels or fewer in width
% and/or height), consider that to be a "stop signal" 

%displaying the image named by jName
close all
P=imread(jName);
[nr,nc,~]=size(P);
imshow(P)
figure(1)
title('Make two clicks to select a rectangular area','Fontsize',14)
c=[inf,0]; r=[inf,0];
while  abs(r(2)-r(1))>4 && abs(c(2)-c(1))>4
 %Accept 2 user mouseclicks on original image defining a rectangular area
[xvec, yvec]=ginput(2);
%if user clicks outside the image use the nearest pixel
xvec(:)= max(1,xvec(:)); xvec(:)= min(nc,xvec(:));
yvec(:)= max(1,yvec(:)); yvec(:)= min(nr,yvec(:));
%Ensure cordinates are integers
r=round(yvec(:)); c=round(xvec(:));
%If area selected is too small
if abs(r(2)-r(1))<=4 || abs(c(2)-c(1))<=4
    newIm=uint8([]);
else
%Identify the selected(area)-submatrix of the original image
if c(2)<c(1)
    if r(2)<r(1)
         SubMat=P(r(2):r(1),c(2):c(1),:);
    else
         SubMat=P(r(1):r(2),c(2):c(1),:);
    end
else
     if r(2)<r(1)
         SubMat=P(r(2):r(1),c(1):c(2),:);
     else
         SubMat=P(r(1):r(2),c(1):c(2),:);
     end
end
     newIm=Interpolate2D(SubMat);  %Compute the "zoom detail"
end
figure         % start new figure window
imshow(newIm); % newIm (uint8 array) contains the zoom detail data
[yr,xc,~]=size(newIm);
if isempty(newIm)
    title('Goodbye!','Fontsize',50)
    pause(2)
    close
    figure(1) % bring figure 1 forward
    title('')
else
    title(['Selected Area ',num2str(yr),' by ',num2str(xc),])
    pause(2)
    figure(1) % bring figure 1 forward
end
end
end
%----------------------------------------------------------------------------------------------------------------------
function newM=Interpolate2D(M)
% Perform 2-d interpolation on the type double, nr-by-nc matrix M.
% The interpolated data are added between existing data points so newM is
% (2*nr-1)-by-(2*nc-1). Use the simple average as the interpolated value.
[nr,nc,np]=size(M);
newM=zeros((2*nr-1),(2*nc-1),np);
for a=1:np
for i=1:2:(2*nr-1)
    k=0;
    for j=1:2:(2*nc-1)
        newM(i,j,a)=M((i/2+0.5),(j/2+0.5),a);
        if k>=1
        newM(i,j-1,a)=(M((i/2+0.5),(j/2+0.5),a)+M((i/2+0.5),(j/2+0.5)-1,a))*0.5;
        end
        k=k+1;
    end
end
end

for i=1:2:(2*nr-1)
        if i>1
        newM(i-1,:,:)= (newM(i,:,:)+ newM(i-2,:,:))*0.5;
        end
end
newM=uint8(newM);
end



