 function n=genes3frames(data, result) 
%reads a DNA data file called data.txt in the current directory, 
%data  : file name to be read.The .txt extention is omited
%result: name of the gene file to be created.The .txt extention is omited
%identifies all the genes in the sequence in the data file, 
%writes the genes to a file called result.txt, and stores in variable n 
%the number of genes found. 

%Read file and change it into a cell array
fid= fopen([data,'.txt'],'r');
k= 0;
while ~feof(fid)
k= k+1;
Csq{k}= fgetl(fid);
end
fclose(fid); %Cell array containing neucleotide sequence

%Convert the cell array into a vector of type char
Sq=cell2charVect(Csq);      %Sq: Whole sequence of neucleotides

%Divide the row vector into codons with respect to all frames
%store them in a cell array as independent length 3 char arrays
[f2,f3,f1]= divideCharArray3(Sq);

%Check for the start codon closest to a stop codon
%The start and stop codons are not stored int the cell array "Found".
%Stored portion is the gene
[n,Found]= Search(f1,f2,f3);

%If genes are not found print a gene-not-found message
if isempty(Found)
    disp('No Genes were found!')
else                       %else,write a file containing the genes found
    fid= fopen([result,'.text'],'w');
[nr, nc]=size(Found);
for i= 1:nr
    for k=1:nc
           fprintf(fid, '%s',Found{i,k});
    end
    if i<nr
    fprintf(fid,'\n');
    end
end
fclose(fid);
end
end


%-------------------------------------------------------------------------------------------------------------%
function CA= cell2charVect(cell)
%transforms the cell array into a single char row array
%cell is the cell array
%V is the new char array
%first line is just a description of the sequence.start from 2.
n=length(cell);
CA='';
for k=2:n
    CA=[CA,cell{k}];
end
end
%--------------------------------------------------------------------------------------------------------------%
function [f2,f3,f1]= divideCharArray3(A)
%Divides the large row char array into smaller char array of length 3
%The smaller char array represent codons
%The codons in a sequence are bracketed into one cell array
%There are three different sequences;
% f1  first frame-offset by 0
% f2  second frame-offset by 1
% f3  third frame-offset by 2
n=length(A);
f1={}; f2={}; f3={};i=0;
%first frame-offset by 0
for k=1:3:n-2   %denotes start of every codon
    i=i+1;
    f1{i}=A(k:k+2);  %stores each length 3 codon in cell v
end
%second frame-offset by 1
for k=2:3:n-2         %denotes start of every codon
    i=i+1;
    f2{i}=A(k:k+2);  %stores each length 3 codon in cell v
end
%third frame-offset by 2
for k=3:3:n-2         %denotes start of every codon
    i=i+1;
    f3{i}=A(k:k+2);  %stores each length 3 codon in cell v
end
end
%---------------------------------------------------------------------------------------------------------------%
function [a,Found]= Search(f1,f2,f3)
%serches the sequences for genes
%St  Opening codon(start)
%Sp1,Sp2,Sp3   Closing codon(stops).
%traverses the entire sequence overwriting the index of the opening codon 
%untill the closest opening codon to a stop codon is reached
%The opening and closing codons are not included in the gene.
St='ATG'; Sp1='TAG';  Sp2='TAA';  Sp3='TGA';
Found= {}; a=1; j=0;
for f=1:3
    if f==1
        C=f1;
    elseif f==2
        C=f2;
    else
        C=f3;
    end
n=length(C); x=0; i=0;
%X and (k-i)>1: measures to avoid overlapping and creation of empty genes
for k=1:n
    if strcmp(C{k},St)
        i=k;
    end
    if(strcmp(C{k},Sp1)||strcmp(C{k},Sp2)||strcmp(C{k},Sp3))&&x~=i&&(k-i)>1
        for m=i+1:k-1
        j=j+1;
        Found{a,j}=C{1,m};
        end
        j=0;a=a+1;x=i;
    end
end
end
a=a-1;
end
%--------------------------------------------------------------------------------------------------------------%

