
%System of linear equations
%Script: Finding the positions x in a spring-mass system

%Spring constants k in lbs/in
k1=100; k2=50; k3=75; k4=200;

%Force applied in lbs
F=2000;

%Create a matrix A of coefficients
A=[-k2-k1   k2     0      0;
      k2  -k3-k2   k3     0;
      0      0   -k4-k3  k4;
      0      0    -k4    k4];
%Create a matrix b of constants  
b=[0;
   0;
   0;
   F];

%Find the matrix x showing the positions 
x=A\b;

%Display values of x from x1 through x4
fprintf('x1= %f\nx2= %f\nx3= %f\nx4= %f\n',x(1),x(2),x(3),x(4))



