% testScript for Project 6 classes

close all

% Test class Interval
i1= Interval(3,9);  % Instantiate an Interval with endpoints 3 and 9
L= i1.left          % Should be 3. The properties have the attribute "public"  
                    %  so it is possible to access the property left directly.
a2= i1.overlap( Interval(5,15) )
                    % o references an Interval with endpoints 5 and 9.
w= a2.getWidth()    % Should be 4, the width of the Interval referenced by a2


% Test class Event

% Test class Schedule

% Test class Course