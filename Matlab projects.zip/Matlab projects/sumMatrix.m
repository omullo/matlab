function s=sumMatrix(M)
[nr,nc]=size(M);
s=0;
for c=2:2:nc
    for r=1:nr
        s=s+M(r,c);
    end
end