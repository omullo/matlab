
 function val=isValidPartition(subarray)
 %val is a type logical value and subarray is either a length 9 or 3-by-3
 %matrix.
 %function determines if integers in subarray matrix contain only the 
 %integers in the range [1...9].
 
 %If function is a length 9 vector
 if length(subarray)==9
     %check if subarray elements are not the same
     if subarray(1)==subarray(2)
         val=false
     %if the numbers are different, check that the sum is 45 because the 
     %sum of numbers [1...9] is 45
     elseif sum(subarray)~=45
        val=false
     else
         val=true
     end
 %if the subarray is 3-by-3 matrix
 elseif size(subarray)==[3 3]
     %check that the numbers are not the same
     if subarray(1,1)==subarray(1,2)
         val=false
     elseif sum(sum(subarray))~=45
         val=false
     else
        val=true
     end
 else
     val=false
 end
     
