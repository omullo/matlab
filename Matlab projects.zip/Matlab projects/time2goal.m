%time2goal script
%code to determine and print how long it takes a rocket to reacha specified
%height 
%Solicit user input
b=input('Enter the fuel burn time\n:');       % time taken to consume all the fuel
H=input('Enter the height required\n:');


%Required constants
mR= 100;%rocket�s mass without the fuel in slugs
q = 1; %rocket�s burn rate in slug per second
u = 8000; %exhaust velocity of the burned fuel
g = 32.2; %acceleration due to gravity in ft per second squared

%height before the fuel burns out(before burn time)
Mo=mR+q*b; % rocket�s+fuel initial mass
                            
for t=1:60
    if t<=b
        h=(u/q)*(Mo-q*t)*reallog(Mo-q*t)+ u*(reallog(Mo) + 1)*t-(g*t^2)/2-(u*Mo/q)*reallog(Mo);
        plot(t,h,'*')
        hold on
    else
        vR=u*reallog(Mo/(Mo-q*t))-(g*t); %Velocity before burn time
        V=vR+g*(t-b); %Velocity after burn time 
        t_max=b +(V/g);
        h=h+V*(t-b)-(g*(t-b)^2)/2;
        plot(t,h,'*')
        title('Graph of duration vs Burn time')
        xlabel('Duration')
        ylabel('Burn time')
        hold on
    end
end

if h==H
    [t,h]=meshgrid(x,y);
    text(x(t),y(h),['t ','h'])
end
    

%This code is incomplete. I had to finish it on my phone. Sorry. 








