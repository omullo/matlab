function newIm=multiZoom(jName)
% function display an image and zooms in user-selected rectangular regions.
% jName is the string that names a JPEG image in the current directory.
% newIm is the uint8 array storing the data of the last "zoom detail." 
%If no zoom detail has been calculated then newIm is the empty uint8 array, 
%uint8([]).
%function continues to run until a narrow rectangular region is selected
%(less than or equal to 4 pixels).

close all
figure(1)
%Convert image to uint8 array
image=imread(jName);
imshow(image)
title('Make two clicks to select rectangular area')
%Calculates number of rows, columns and layers.
[nr,nc,np]=size(image);

%Width and Height of rectangle initialized to very large number
width=inf; height=inf;

%As long as rectangular region selected is greater than 4 pixels in height
%and width, zooming continues
while width>=4 && height>=4  
%Creates vectors that stores the row and column number of the clicks    
[colVec,rowVec]=(ginput(2));
%Updates width and height of rectangular region
width=abs(colVec(2)-colVec(1));
height=abs(rowVec(2)-rowVec(1));

x1=floor(rowVec(1)); x2=floor(rowVec(2));y1=floor(colVec(1));y2=floor(colVec(2));
%newIm initialized to empty uint8 array
newIm=uint8([]);

%if second click to the right and above first click
if colVec(1)<colVec(2) && rowVec(1)>rowVec(2)
    if colVec(2)>nc && rowVec(2)<1  
        y2=nc;
        x2=1;
    elseif colVec(1)<1 && rowVec(1)>nr 
        y1=1;
        x1=nr;
    elseif colVec(2)>nc
        y2=nc;
    elseif colVec(1)<1
        y1=1;
    elseif rowVec(2)<1
        x2=1;
    elseif rowVec(1)>nr
        x1=nr;
    end
 newIm=uint8(image(x2:x1,y1:y2,:));
%if second click to the left and above first click
elseif colVec(1)>colVec(2)&& rowVec(1)>rowVec(2)
    if colVec(2)<1 && rowVec(2)<1
        x1=1;
        y1=1;
    elseif colVec(1)>nr && rowVec(1)>nr
        x1=nr;
        y1=nc;
    elseif colVec(2)<1
        y2=1;
    elseif rowVec(2)<1
        x2=1;
    elseif rowVec(1)>nr
        x1=nr;
    elseif colVec(1)>nc
        y1=nc;
    end
    newIm=uint8(image(x2:x1,y2:y1,:));
%if second click to the right and below first click
elseif colVec(1)<colVec(2) && rowVec(1)<rowVec(2)
    if colVec(2)>nc && rowVec(2)>nr
        x2=nr;
        y2=nc;
    elseif colVec(1)<1 && rowVec(1)<1
        x1=1;
        y1=1;
    elseif colVec(1)<1
        y1=1;
    elseif rowVec(1)<1
        x1=1;
    elseif rowVec(2)>nr
        x2=nr;
    elseif colVec(2)>nc
        y2=nc;
    end
    newIm=uint8(image(x1:x2,y1:y2,:));
%if second click to the left and below first click
elseif colVec(1)>colVec(2) && rowVec(1)<rowVec(2)
       if colVec(1)>nc && rowVec(1)<1
           y1=nc;
           x1=1;
       elseif colVec(2)<1 && rowVec(2)>nr
           y2=1;
           x2=nr;
       elseif colVec(1)>nc
           y1=nc;
       elseif colVec(2)<1
           y2=1;
       elseif rowVec(1)<1
           x1=1;
       elseif rowVec(2)>nr
           x2=nr;
       end
    newIm=uint8(image(x1:x2,y2:y1,:));

end

 newIm=double(newIm);
newIm=uint8(Interpolate2D(newIm));

figure(2) 
imshow(newIm)
title('Detail of selected area')
pause(2)

figure(1)
title('Make two clicks to select rectangular area')
end
%If pixels are less than or equal to 4, zooming stops
if width<=4 || height<=4
    figure(1)
    title('GOODBYE')
    pause(2)
    close all
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function newM=Interpolate2D(M)
% Performs 2-d interpolation on the type double, nr-by-nc matrix M.
% The interpolated data are added between existing data points so newM is
% (2*nr-1)-by-(2*nc-1) using the simple average as the interpolated value.

[nr,nc,np]=size(M);
%Initialize newM to zeros matrix
newM=(zeros(2*nr-1,2*nc-1,np));


for r=1:nr
    for c=1:nc
        for p=1:np
            newM(2*r-1,2*c-1,p)=M(r,c,p); 
        end
       
    end
end

for c=1:nc
    for r=1:nr-1
        for p=1:np
            newM(2*r,2*c-1,p)=(M(r,c,p)+M(r+1,c,p))/2;
        end
    end
end

[NR,NC,np]=size(newM);
for r=1:NR
    for c=1:NC
        for p=1:np
            if rem(c,2)==0
               newM(r,c,p)=(newM(r,c-1,p)+newM(r,c+1,p))/2;
            end
        end
    end
end
end

