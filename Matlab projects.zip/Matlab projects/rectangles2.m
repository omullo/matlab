close all
n=4; xmax=6; ymax=4; colorS=[0.9 0.6 0.7]; colorL=[0.1 0.8 0.9]; %magenta
Area=[];
figure(1)
Z=rectArray(n,xmax,ymax);
hold off

for i=1:n
    xc=(Z{i}.left+Z{i}.right)/2;
    Length=2*(xc-Z{i}.left);
    yc=(Z{i}.bot+Z{i}.top)/2;
    Width=2*(yc-Z{i}.bot);
    Area(i)=Length*Width;
end

[y,idx]=sort(Area);

for j=n:-1:1
    
    %f=(j-1)/(n-1);
    f=(y(j)-y(1))/(y(n)-y(1));
    c=f*colorL+(1-f)*colorS;
    figure(2)
    %axis([0 xmax 0 ymax])
    hold on
%     if j==n
%         ShowRect(Z{idx(j)},colorL)
%         text(0,ymax+.5,'Biggest','Color',colorL,'Fontsize',20)
%     elseif j==1
%            ShowRect(Z{idx(j)},colorS)
%            text(xmax-2,ymax+.5,'Smallest','Color',colorS,'Fontsize',20)
%     else
    ShowRect(Z{idx(j)},c)
    
end
hold off

    