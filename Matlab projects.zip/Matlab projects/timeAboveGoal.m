%timeAboveGoal
%determine the amount of time that the rocket would spend above a specified
%height as a function of the burn time b.

mR= 100;    %rocket�s mass without the fuel in slugs
q = 1;      %rocket�s burn rate in slug per second
u = 8000;   %exhaust velocity of the burned fuel
g = 32.2;   %acceleration due to gravity in ft per second squared
Mo=100+mR;  %rocket�s mass with the fuel in slugs
b=100;  %rocket�s Maximum burn time in seconds
H=input('Enter the height required\n:');

for t=1:b
    vR=u*reallog(Mo/(Mo-q*t))-(g*t);    %Velocity before burn time
    V=vR+g*(t-b);                       %Velocity after burn time 
end

  h=(u/q)*(Mo-q*b)*reallog(Mo-q*b)+ u*(reallog(Mo) + 1)*b-(g*b^2)/2-(u*Mo/q)*reallog(Mo);
  h_Max=h+(V^2)/(2*g);
  t_max=b +(V/g);
  t_ground=t_max+sqrt(2*h_Max/g);

if H<h_Max
for t=1:1:t_ground
    if t<=b
        h=(u/q)*(Mo-q*t)*reallog(Mo-q*t)+ u*(reallog(Mo) + 1)*t-(g*t^2)/2-(u*Mo/q)*reallog(Mo);
    else
        h=(u/q)*(Mo-q*b)*reallog(Mo-q*b)+ u*(reallog(Mo) + 1)*b-(g*b^2)/2-(u*Mo/q)*reallog(Mo);
        h=h+V*(t-b)-(g*(t-b)^2)/2;
    end
    plot(t,h,'*')
    hold on
end
else
  fprintf('Sorry! The required height can not be attained')
end

%I Need Help