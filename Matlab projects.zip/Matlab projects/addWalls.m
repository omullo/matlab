function addWalls(x,y,w,h)
% Recursively partition the chamber of width w and height h using randomly
% placed vertical and horizontal walls with random openings until all
% chambers have at least one side with unit length.
% x, y, w, and h are each an integer; w and h are positive.

if w<=1 || h<=1  %base case
   return        %no perpendicular lines drawn if condition is satisfied
else

%generate random gridpoint within the borders    
x_in=myRandInt(x+1,x+w-1);
y_in=myRandInt(y+1,y+h-1);

%Draw the perpendicular lines
plot([x_in x],[y_in y_in],'k','LineWidth',2)   %wall 1
plot([x_in x+w],[y_in y_in],'k','LineWidth',2) %wall 2
plot([x_in x_in],[y_in y],'k','LineWidth',2)   %wall 3
plot([x_in x_in],[y_in y+h],'k','LineWidth',2) %wall 4

%Randomly create openings
           %Currently...
 wall_1=0; %no opening on wall 1 
 wall_2=0; %no opening on wall 2
 wall_3=0; %no opening on wall 3
 wall_4=0; %no opening on wall 4
 nWalls=0; %total number of walls with openings is set at 0
 
 while nWalls~=3    %create openings on 3 randomly generated walls and stop
                    %only when total number of walls with openings is 3
                    
 wall=myRandInt(1,4); %generate random wall number
 
 %if wall 1 is randomly picked and there is no opening on wall 1,
 %create an opening.
 if wall==1 && wall_1==0 
   opening=myRandInt(x+1,x_in-2);
   plot([opening opening+1],[y_in y_in],'w','LineWidth',2)
   %wall 1 now has an opening
   wall_1=1;
   %current number of walls with openings is increased by 1
   nWalls=nWalls+1;
   
 elseif wall==2 && wall_2==0
        opening=myRandInt(x_in+1,x+w-2);
        plot([opening opening+1],[y_in y_in],'w','LineWidth',2)
        
        wall_2=1;
        
        nWalls=nWalls+1;
       
 elseif wall==3 && wall_3==0
        opening=myRandInt(y+1,y_in-2);
        plot([x_in x_in],[opening opening+1],'w','LineWidth',2)
        
        wall_3=1;
        
       nWalls=nWalls+1;
     
 elseif wall==4 && wall_4==0
    opening=myRandInt(y_in+1,y+h-2);
     plot([x_in x_in],[opening opening+1],'w','LineWidth',2)
     
     wall_4=1;
     
     nWalls=nWalls+1;
 end
 
 end
 
 %Add partitions
 addWalls(x,y,x_in-x,y_in-y)
 addWalls(x_in,y_in,x+w-x_in,y+h-y_in)
 addWalls(x_in,y,x+w-x_in,y_in-y)
 addWalls(x,y_in,x_in-x,y+h-y_in)

 end

