%creating a 4*4 matrix A�the coefficients of the 4 unknowns in 4 
%equations�and the length 4 column vector b�the constants on the right
%side of the re-arranged equations.
k_1=100; k_2=50;k_3=75;k_4=200;
F=2000;
A=[(-k_1-k_2) k_2 0 0;k_2 (-k_2-k_3) k_3 0; ...
    0 k_3 -k_4-k_3 k_4;0 0 -k_4 k_4];
b=[0;0;0;F];
    
%Applying the matrix left division operator to solve for
%x1, x2, x3, and x4.
x = A\b;
% Display the values of x1 through x4 neatly.
for k=1:4
    fprintf('x%d is %3.1f\n',k,x(k))
end