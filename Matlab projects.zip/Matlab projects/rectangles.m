function [colrZ, colrSorted] = rectangles(Z,xmax,ymax,colorS,colorL)
% Draw the rectangles in struct array Z:
% Figure 1 draws the rectangles in the order Z(1), Z(2), ..., Z(n), where n
% is the length of Z. Draw all rectangles in one color of your choice.
% Figure 2 draws the rectangles starting from the largest (by area) to the
% smallest. The colors of the rectangles are linearly interpolated with
% the largest area corresponding to colorL and the smallest area
% corresponding to colorS.
% xmax and ymax are the upper limits of the x- and y-axes in the figures.
% The lower limit of the x- and y-axes is 0.
% colrZ is the n-by-3 matrix where colrZ(k,:) are the rgb values of Z(k).
% colrSorted is the n-by-3 matrix where colrSorted(i,:) are the rgb values
% of the ith smallest rectangle.

n=length(Z);

%Create empty area array
Area=[];

colrZ=[1 0 1]; 

%Find the area of each rectangle and store it in vector Area
for i=1:n
    Length=Z(i).rectangles.right-Z(i).rectangles.left;
    Width=Z(i).rectangles.top-Z(i).rectangles.bot;
    Area(i)=Length*Width;
    colrZ=[colrZ;1 0 1];
end

%Sort the area of the rectangles in ascending order
[sortArea,idx]=sort(Area);

colrSorted=[];

figure(2)
axis('equal')
axis([0 xmax 0 ymax])
hold on
for rect=n:-1:1 %start from largest to smallest
    
    %interpolate the color where f is the fraction by which the
    %interpolation is done
    f=(sortArea(rect)-sortArea(1))/(sortArea(n)-sortArea(1));
    c=f*colorL+(1-f)*colorS;
    colrSorted=[colrSorted;c];
    
    text(0,ymax+.9,'Biggest','Color',colorL,'Fontsize',15)
    text(xmax-5,ymax+.9,'Smallest','Color',colorS,'Fontsize',15)
    ShowRect(Z(idx(rect)).rectangles,c)
    
end
hold off

    