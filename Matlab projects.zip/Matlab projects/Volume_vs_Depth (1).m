%script Volume_vs_Depth
%Volume of a liquid in the tank at different fill depths
%Plotting graph of findings Volume_vs_Depth

% Solicit input for r, h, and n.
r=input('Enter the radius of the tank in meters:');
h=input('Enter the height of the tank in meters:');
%Change h if necessary
if h<=2*r
    h=2*r+1;
end
n=input('Enter the number of fill depths to consider:');
%n should be an integer greater than 2
if n<=2
    n=3;
end

close all % Close all figure windows
figure % Start a figure window
title('Volume of water in the tank vs Depth')
xlabel('Fill Depth')
ylabel('Volume in cubic meters')
hold on % Keep all subsequent plot commands on same axes

for d=0:(h/(n-1)):h
%calculating the volume
a=sqrt(d*(2*r-d));                     %small radius of water in bottom cap
V_in_BottomCap=(1/6)*pi*d*(3*a^2+d^2); %Vol of water in bottom cap,d<r
V_of_BottomCap=(2/3)*pi*r^3;           %Vol of a full bottom cap,d=r
V_in_Cylinder=pi*r^2*(d-r);            %vol in cylinder,d > r below top cap
V_of_Cylinder=pi*r^2*(h-2*r);          %Vol of full cylindrical part

%Volume of water in top spherical cap when d>(h-r)
V_of_TopCap=(2/3)*pi*r^3;              %Volume of a full top cap
a=sqrt((h-d)*(2*r-(h-d)));             %small radius of water is in top cap
V_in_TopCap= V_of_TopCap-((1/6)*pi*(h-d)*(3*a^2+(h-d)^2));

if d<=r
    V=V_in_BottomCap;
    plot(d,V,'c*');hold on
elseif d>r && d<=(h-r)
    V=V_of_BottomCap+V_in_Cylinder;
    plot(d,V,'b*');hold on
else
    V=V_of_BottomCap+V_of_Cylinder+V_in_TopCap;
    plot(d,V, 'm*');hold on
axis([0 d 0 V])
end
end

        
        
        
        
