M=[12 16 9 5 7 1;...
    13 17 80 1 5 7;...
    68 66 13 7 1 5];
for r=1:3
    c=1;
    d=6;
   while c<3
      M(r,c)=M(r,d);
      c=c+1;     
      d=d-1;
   end
end
    disp(M)