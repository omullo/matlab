function m=isValidSudoku(filledPuzzle)
%Function returns type logical value true if the following is true:
%1. The provided solution fits in a 9-by-9 grid.
%2. The entire board contains only integers in the range [1, 9].
%3. Each row contains the numbers [1..9], with no repeated values.
%4. Each column contains the numbers [1..9], with no repeated values.
%5. Each 3-by-3 sub-grid contains the numbers [1..9],unrepeated.
%Otherwise the logical value false is returned.
[nr, nc]=size(filledPuzzle);
%Checking if solution fits in a 9-by-9 grid.
m=nr==9&&nc==9;

%Checking if each column and row contains the numbers [1..9] unrepeated
k=1;
while m==1&&k<=nr
m=isValidPartition(filledPuzzle(k,:));
if m==1
m=isValidPartition(filledPuzzle(:,k));
end
k=k+1;
end
%Creating 3*3 sub-grid out of the entered solution grid
%Checking if each 3*3 sub-grid contains the numbers [1..9],unrepeated
%Ensuring any logical value false is not over written
a=0;
for k=1:3:7  
  for l=3:3:9
    while a<=3 && m==1
        for i=1:3:7
            for j=3:3:9 
                if m==1
                    m=isValidPartition(filledPuzzle(k:l,i:j));
                end
            end
        end
     a=a+1;
     end  
  end
end
end
        

