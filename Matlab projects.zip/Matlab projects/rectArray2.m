function Z=rectArray(n,xmax,ymax)

Z={};
%Generate centers
for i=1:n
xc=floor(rand*xmax);
yc=floor(rand*ymax);
% L=ceil(0.5+0.5*rand);
% W=ceil(0.5+0.5*rand);

% %L to the right of center
 L1=floor(rand*(xmax-xc)+xc);
% 
% %L to the left of center
 L2=floor(rand*xc);
% 
% %Generate Length
 d=L1-xc;
 e=xc-L2;
% 
% if d==0 
%    L=e/2;
% elseif e==0
%     L=d/2;
% else
 L=min(d,e);
% end
% 
% 
 W1=floor(rand*(ymax-yc)+yc);
 W2=floor(rand*yc);
 f=W1-yc; g=yc-W2;
% if f==0
%     W=g/2;
% elseif g==0
%     W=f/2;
% else
 W=min(f,g);
% end
% 
%     

a=xc-L;
b=xc+L;
c=yc-W;
d=yc+W;
    R=MakeRect(a,b,c,d);
    Z{i}=R;
    hold on
    ShowRect(R,'y')
    hold off
end
    %Z(i)=R;
    %end.
    
%end