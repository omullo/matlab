%Script P1.1.4
%Oblate Spheroid area
r1=input('enter the equatorial radius:');
r2=input('enter the polar radius:');
% Let g represent the gamma symbol, couldn't find it in matlab
g=acos(r2/r1);
A(r1,r2)=2*pi*((r1)^2+((r2)^2/sin(g)))*log(((cos(g))/(1-(sin(g)))));
approx=4*pi*((r1+r2)/2)^2;

fprintf('The surface area of the oblate spheroid is %s\n %6.5f',a(r1,r2))
fprintf('The approximation of the surface area is %s\n %6.5f' ,approx)

%Display of the elipticity
e=sqrt(1-(r2^2/r1^2));
fprintf('The elipticity of the sphere is %s\n %6.5f', e)


