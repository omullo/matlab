function m=isValidPartition(subarray)
%Function returns type logical value true if the following is true:
%subarray is a length 9 vector or a 3-by-3 matrix
%subarray contains the numbers [1..9] with no repeated values.
%Otherwise the logical value false is returned.

[nr, nc]=size(subarray);
%Checking whether the subarray is a length 9 vector or a 3-by-3 matrix
m=(nc==9&&nr==1)||(nc==1&&nr==9)||(nc==3&&nr==3);
count=zeros(1,9);
i=1;
j=1;
%Checking if the subarray has any repeated integers or >9 integers
%Stops traversing as soon soduku rules are violated
while i<=nr && m==1
    while j<=nc && m==1
    m=subarray(i,j)<=9;
        if m==1
        count(1,subarray(i,j))=count(1,subarray(i,j))+1;
        m=count(1,subarray(i,j))==1;
        end
        j=j+1;
    end
j=1;
i=i+1;
end
end
    
