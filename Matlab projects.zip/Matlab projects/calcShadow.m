% Script calcShadow
% Position a light source and a box in a room and determine the extent of
% the shadow cast by the box.

% Set up the window
close all         % Close all previous figure windows
figure            % Start a new figure window
hold on           % Keep the same set of axes (multiple plots on same axes)
axis equal        % unit lengths on x- and y-axis are equal
axis([0 10 0 10]) % x-axis limits [0,10], y-axis limits [0,10]

% Top left corner of box, point T
xt=5;  yt=7;
plot(xt, yt, 'bo')           % Format Blue circle
plot([xt xt], [1 yt], 'k:')  % Format blacK dotted line
text(xt, yt, '  T')

%%% Do not change the code above %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Modify the code below %%%%%%%%%%

% Light source, point L
xL=5*rand;  yL=3*rand+7;
plot(xL, yL, 'r*')           % format Red asterisk
text(xL, yL, '  L')

% Draw a black solid line from point T to (10,7))
plot([xt 10],[yt 7], 'k-')

% User-clicked point
title('Click on the dotted line below')
[xu, yu]= ginput(1);
plot(xu, yu, 'm+')          % Format Magenta cross
text(xu, yu, '  U')
messageToShow= sprintf('LIGHT SOURCE L (%.1f,%.1f)', xL, yL);
title(messageToShow)

%Draw a black solid line from point T to U
%Basically drawing the edges of the rectangle
plot ([xt xt],[yt yu],'k-')
plot([xt 10],[yu yu],'k-') % line from U to YU
plot([10 10],[yu yt],'k-') %line from yu to 10,7
plot([xL xt],[yL yu],'k:')

%plot a line between L and the furthest extent of the shadow-Ray diagram
m=(yL-yu)/(xL-5);b=(yL-xL*(yL-yu)/(xL-5));x=xL:10;
plot(x,m*x+b,'r:')
%let x2,y2 be the point of intersection between the red line and x =10
%let x3,y3 be the point of intersectionbetween the red line and y=0
y2=10*(yL-yu)/(xL-5)+yL-xL*(yL-yu)/(xL-5);
x3=xL-yL*(xL-5)/(yL-yu);
if y2>0
    plot ([10 10],[y2 yu],'b-','LineWidth',3)
    fprintf('the  furthest extent of the shadow')
else
    plot ([x3 10],[0 0],'b-','LineWidth',3)
    plot ([10 10],[0 yu],'b-','LineWidth',3)
end
    
  
    





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Do not change the code below %%%

hold off