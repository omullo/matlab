function Z = rectArray(n,xmax,ymax)
% Z is a 1-d array of n rectangle structs, each as defined by function
% MakeRect and each is randomly generated in the area bounded by (0,0),
% (xmax,0), (xmax,ymax), and (0,ymax). The first generated rectangle is
% Z(1), the second generated rectangle is Z(2), and so forth.
% >>>>>a and b are real numbers that satisfy a <= b.
% c and d are real numbers that satisfy c <= d.
%  R.a <= x <= R.b, R.c <= y <= R.d<<<<<<<
Z={};
for k=1:n
    a=floor(rand*(xmax+1))
    b=floor(rand*(xmax+1))
    while a>=b
        b=floor(rand*(xmax+1))
    end
    d=floor(rand*(ymax+1))
    c=floor(rand*(ymax+1))
    while c>=d
        c=floor(rand*(ymax+1))
    end
    Z{k}=MakeRect(a,b,c,d);
end