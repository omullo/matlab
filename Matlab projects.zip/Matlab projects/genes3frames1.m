function n=gene3frames(data,result)
%function finds all the genes in a partial genomic sequence
%n is the total number of genes found in the three different reading
%frames from zero offset, offset by one and offset by two.
%data is a plain text file that contains the the partial genomic sequence
%result is the plain text file that contains the genes found; each
%line corresponds to gene found and is exactly the length
%one gene

%Store the data in the text file in a cell array dataArray
dataArray=file2cellArray(data);

%Create one long genomic sequence using the subfunction 'concatenate'
sequence=concatenate(dataArray);

%Initialize gene to be an empty cell array
gene={};

%number of genes found so far is zero
n=0;

%Use for loop to find the genes in the different reading frames
for frame=1:3
    %subgene is a char array that houses the codons found that are
    %part of the main gene
    %for every reading frame, subgene is reset to empty char
    subgene='';
    
    %s_ind is the index number of the char array subgene. Preset to 1
     s_ind=1;
    
    %foundStart and foundStop are logical variables that return the
    %logical values true or false, indicating whether a start or stop codon
    %have been found already as the search was carried out
    %currently, no start or stop codon have been found.
    foundStart=false;
    foundStop=false; 
    
    %Use for-loop to extract codons from sequence 
   for index=frame:3:length(sequence)-2
   %codon is a 1x3 char array    
       codon=sequence(index:index+2);
    
   %Check if the codon generated is a start codon using subfunction 
   %'isStart'
          if isStart(codon)
             foundStart=true;
          end
        
   %if start codon has been found, and the codon generated is neither
   %a stop codon, input in the array subgene that codon generated
           if ~isStop(codon) && ~isStart(codon) && foundStart==true
                subgene(s_ind:s_ind+2)=codon;
           %Increment the s_ind by 3
                s_ind=s_ind+3;
           end
    
    %if codon generated is a stop codon and a start codon has already 
    %been found, foundStop is set to true.
           if isStop(codon) && foundStart==true
              foundStop=true;
           end
           
    %if codon generated is a start codon but another start codon was 
    %already found, delete the codons that were put in subgene and
    %reset s_ind to 1 as if no gene was found
           if isStart(codon) && foundStart==true && foundStop==false
               s_ind=1;
               subgene='';
           end

    %if a start and stop codon occur consecutively, reset foundStart
    %and foundStop to false statements as there is no gene found
           if length(subgene)==0 && foundStart==true && foundStop==true
              foundStart=false;
              foundStop=false;
           end
      
    %if start codon and stop codon were found, begin building the gene cell
    %array
           if foundStart==true && foundStop==true
           %number of genes found so far incremented by 1
              n=n+1;
           %each element in the cell array gene gets the subgene that was
           %generated
              gene{n}=subgene;
       
           %As soon as a gene is found, reset subgene, foundStart, foundStop
           %and s_ind to initial values
              subgene='';
              s_ind=1;
              foundStart=false;
              foundStop=false;
           end
           
    end
     
end

%Convert the cell array gene into a plain text file with the specified name
  cellArray2file(gene,result)

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function cellArray2file(CA, fname)
% CA is a cell array of strings.
% Create a .txt file with the name
% specified by the string fname.
% The i-th line in the file is CA{i}

fid= fopen([fname '.txt'], 'w');
for i= 1:length(CA)
    fprintf(fid, '%s\n', CA{i});
end
fclose(fid);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
function CA = file2cellArray(fname)
% fname is a string that names a .txt file in the current directory.
% CA is a cell array with CA{k} being the k-th line in the file.

fid= fopen([fname '.txt'], 'r');
k= 0;
while ~feof(fid)
   k= k+1;
   CA{k}= fgetl(fid);
end
fclose(fid);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function check=isStart(codon)
%function checks if particular codon is a start codon and returns true
%codon is a start codon and false if codon is not a start codon.
if strcmp('ATG',codon)
    check=true;
else
    check=false;
end
end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function check=isStop(codon)
%function checks if codon is a stop codon and returns true if it is and
%false if it not
if strcmp('TGA',codon) || strcmp('TAG',codon) || strcmp('TAA',codon)
    check=true;
else
    check=false;
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function sequence=concatenate(CA)
%function converts the data cell array into one long sequence.
%returns the long generated sequence and works on the assumption that
%the the first column does not contain any nucleotide sequences
nc=size(CA,2);
sequence=[CA{2:nc}];
end
    
